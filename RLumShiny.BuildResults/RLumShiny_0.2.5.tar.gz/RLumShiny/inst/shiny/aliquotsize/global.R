## global.R ##
library(Luminescence)
library(RLumShiny)
library(shiny)
library(data.table)

enableBookmarking(store = "server")
