## global.R ##
library(Luminescence)
library(shiny)
library(leaflet)
library(RLumShiny)

enableBookmarking(store = "server")
